package com.bd.imagetextedit;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.app.AlertDialog;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View.OnClickListener comingSoon = new View.OnClickListener() {
            @Override public void onClick(View v) {
                String title = "Premium Tool";
                if (v.getId() == R.id.btnStart || v.getId() == R.id.toolImport) title = "Import Photo";
                else if (v.getId() == R.id.toolText) title = "Add Text";
                else if (v.getId() == R.id.toolEdit) title = "Edit Design";
                else if (v.getId() == R.id.toolSave) title = "Export Image";
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle(title)
                    .setMessage("This tool UI is ready. The image editing engine will be added in the next build.")
                    .setPositiveButton("Got it", null)
                    .show();
            }
        };
        findViewById(R.id.btnStart).setOnClickListener(comingSoon);
        findViewById(R.id.toolImport).setOnClickListener(comingSoon);
        findViewById(R.id.toolText).setOnClickListener(comingSoon);
        findViewById(R.id.toolEdit).setOnClickListener(comingSoon);
        findViewById(R.id.toolSave).setOnClickListener(comingSoon);
    }
}
